﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCUsingEntityFramework.Models;

namespace MVCUsingEntityFramework.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/

        //
        // GET: /Employee/
        EmployeeEntities context = new EmployeeEntities();

        public ActionResult Index()
        {
            return View(context.EmployeeDNs);

        }

        public ActionResult Details(int id)
        {
            return View(context.EmployeeDNs.Find(id));
        }

        public ActionResult CreateEmployee()
        {

            return View();

        }

        [HttpPost]
        public ActionResult CreateEmployee(EmployeeDN emp)
        {

            if (ModelState.IsValid)
            {
                context.EmployeeDNs.Add(emp);
                context.SaveChanges();

                return RedirectToAction("index");
            }
            else
            {
                return View(emp);
            }

        }

        public ActionResult UpdateEmployee(int id)
        {

            return View(context.EmployeeDNs.Find(id));

        }

        [HttpPost]
        public ActionResult UpdateEmployee(EmployeeDN emps)
        {

            if (ModelState.IsValid)
            {
                EmployeeDN emp = new EmployeeDN();
                emp = context.EmployeeDNs.First(e => e.empid == emps.empid);
                emp.name = emps.name;
                emp.salary = emps.salary;
                emp.city = emps.city;
                context.SaveChanges();

                return RedirectToAction("index");
            }
            else
            {
                return View();
            }

        }

        public ActionResult DeleteEmployee()
        {
            return View();
        }

        [HttpPost]
        public ActionResult DeleteEmployee(int id)
        {
            EmployeeDN emp = new EmployeeDN();
            if (ModelState.IsValid)
            {
                emp = context.EmployeeDNs.Find(id);
                context.EmployeeDNs.Remove(emp);
                context.SaveChanges();

                return RedirectToAction("index");
            }
            else
            {
                return View();
            }

        }

        public ActionResult SearchEmployeesByCity(string cityname)
        {
            EmployeeDN emp = new EmployeeDN();

            var searchEmp = (from eq in context.EmployeeDNs
                             where (eq.salary >= 20000 && eq.salary <= 50000) && eq.city == "Mumbai"
                             select eq);
            return View(searchEmp);


        }

    }
}
