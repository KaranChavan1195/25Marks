﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EMS.PL
{
    public partial class Company : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public bool LogoutVisible
        {
            get { return lbtnLogout.Visible; }
            set
            {lbtnLogout.Visible = value;}
        }

        public bool MenuVisible
        {
            get { return menu.Visible; }
            set { menu.Visible = value; }
        }

        protected void lbtnLogout_Click(object sender, EventArgs e)
        {
            Session["user"] = null;
            Response.Redirect("LoginPage.aspx");
        }
    }
}